package com.adowali.hospitalmanagement;

import com.adowali.hospitalmanagement.model.Appointment;
import com.adowali.hospitalmanagement.repository.AppointmentRepository;
import com.adowali.hospitalmanagement.service.AppointmentService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.transaction.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Transactional
public class AppointmentServiceTest {

    @Autowired
    AppointmentService appointmentService;
    @MockBean
    AppointmentRepository appointmentRepository;

    /**
     * In this test case, we are testing our get all appointments' method whether that method
     * is fetching the list or not.
     */
    @Test
    public void getAllAppointmentsTest() {

        Appointment appointment = Appointment.builder()
                .appointmentDate("2022-06-20")
                .appointmentTime("09:30")
                .build();
        List<Appointment> appointments = new ArrayList<>();
        appointments.add(appointment);
        when(appointmentRepository.findAll()).thenReturn(appointments);
        assertEquals(appointments, appointmentService.getAllAppointments());
    }

    /**
     * In this test case we are testing our find appointment by Date,time,and ID.
     * So, we are checking whether it will return us the expected result or not.
     */
    @Test
    void findAppointmentByAppointmentDateAndAndAppointmentTimeAndDoctorIdTest(){

        Appointment appointment = Appointment.builder()
                .appointmentDate("2022-06-20")
                .appointmentTime("09:30 AM")
                .build();

        when(appointmentRepository.findAppointmentByAppointmentDateAndAppointmentTimeAndDoctorId("2022-06-20", "09:30 AM", 1L)).thenReturn(Optional.of(appointment));
        assertTrue(appointmentService.findAppointmentByAppointmentDateAndAndAppointmentTimeAndDoctorId("2022-06-20", "09:30 AM", 1L));
    }

    /**
     * In this test case we are testing our find appointment by Date,and ID.
     * So, we are checking whether it will return us the expected result or not.
     */
    @Test
    public void findAppointmentByAppointmentDateAndDoctorIdTest() {

        Appointment appointment = Appointment.builder()
                .appointmentDate("2022-06-20")
                .appointmentTime("09:30")
                .build();
        List<Appointment> appointments = new ArrayList<>();
        appointments.add(appointment);
        when(appointmentRepository.findAppointmentByAppointmentDateAndDoctorId("2022-06-20", 1L)).thenReturn(appointments);
        assertEquals(appointments, appointmentService.findAppointmentByAppointmentDateAndDoctorId("2022-06-20", 1L));
    }



}
