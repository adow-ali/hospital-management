package com.adowali.hospitalmanagement;

import com.adowali.hospitalmanagement.model.Admin;
import com.adowali.hospitalmanagement.repository.AdminRepository;
import com.adowali.hospitalmanagement.service.AdminService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.transaction.Transactional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Transactional
class AdminServiceTest {

    @Autowired
    AdminService adminService;

    @MockBean
    AdminRepository adminRepository;

    /**
     * In this case, we are testing our admin save test method.
     */
    @Test
    public void saveAdminTest() {
        Admin admin = Admin.builder()
                .fullName("Admin")
                .email("admin@gmail.com")
                .username("admin")
                .password("admin")
                .build();
        when(adminRepository.save(admin)).thenReturn(admin);
        assertEquals(admin, adminService.saveAdmin(admin));
    }
}
