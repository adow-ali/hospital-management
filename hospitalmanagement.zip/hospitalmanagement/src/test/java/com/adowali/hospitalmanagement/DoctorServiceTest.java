package com.adowali.hospitalmanagement;

import com.adowali.hospitalmanagement.model.Appointment;
import com.adowali.hospitalmanagement.model.Doctor;
import com.adowali.hospitalmanagement.repository.AppointmentRepository;
import com.adowali.hospitalmanagement.repository.DoctorRepository;
import com.adowali.hospitalmanagement.service.DoctorService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Transactional
class DoctorServiceTest {

    @Autowired
    DoctorService doctorService;

    @MockBean
    DoctorRepository doctorRepository;

    @MockBean
    AppointmentRepository appointmentRepository;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    /**
     * In this test case we are testing our save doctor method.
     */
    @Test
    public void saveDoctorTest() {
        Doctor doctor = Doctor.builder()
                .id(1L)
                .fullName("Dr Mohamed")
                .email("drmohamed@gmail.com")
                .password("password")
                .age(30)
                .degree("MD")
                .gender("male")
                .phoneNumber("+1320-123-1234")
                .address("MN, St. Cloud")
                .build();
        when(doctorRepository.save(doctor)).thenReturn(doctor);
        assertEquals(doctor, doctorService.saveDoctor(doctor));
    }


    /**
     * In this test case we are testing our get all doctors from database method.
     * So, we are expecting a list of doctors and matching that whether it will return a correct list or not.
     */
    @Test
    public void getAllDoctorsTest() {

        Doctor doctor = Doctor.builder()
                .id(1L)
                .fullName("Dr Mohamed")
                .email("drmohamed@gmail.com")
                .password("password")
                .age(30)
                .degree("MD")
                .gender("male")
                .phoneNumber("+1320-123-1234")
                .address("MN, St. Cloud")
                .build();
        List<Doctor> doctorList = new ArrayList<>();
        doctorList.add(doctor);
        when(doctorRepository.findAll()).thenReturn(doctorList);
        assertEquals(doctorList, doctorService.getAllDoctors());
    }

    /**
     * In this test case we are testing our doctorWithUsername method which is searching a doctor with its username.
     * So, we are expecting a single doctor whose username is that we have entered.
     */
    @Test
    public void doctorWithUsernameTest() {

        Doctor doctor = Doctor.builder()
                .id(1L)
                .fullName("Dr Mohamed")
                .username("mohamed")
                .email("drmohamed@gmail.com")
                .password("password")
                .age(30)
                .degree("MD")
                .gender("male")
                .phoneNumber("+1320-123-1234")
                .address("MN, St. Cloud")
                .build();
        when(doctorRepository.findByUsername("mohamed")).thenReturn(Optional.of(doctor));
        assertTrue(doctorService.doctorWithUsername("mohamed"));
    }


    /**
     * In this test case we are testing our doctorWithEmail method which is searching a doctor with its email.
     * So, we are expecting a single doctor whose email is that we have entered.
     */
    @Test
    public void doctorWithEmailTest() {

        Doctor doctor = Doctor.builder()
                .id(1L)
                .fullName("Dr Mohamed")
                .username("mohamed")
                .email("drmohamed@gmail.com")
                .password("password")
                .age(30)
                .degree("MD")
                .gender("male")
                .phoneNumber("+1320-123-1234")
                .address("MN, St. Cloud")
                .build();
        when(doctorRepository.findByEmail("drmohamed@gmail.com")).thenReturn(Optional.of(doctor));
        assertTrue(doctorService.doctorWithEmail("drmohamed@gmail.com"));
    }


    /**
     * In this test case we are testing our delete doctor method.
     * After successful deletion it will return us true, so if our service returned true
     * it means the method is correct.
     */
    @Test
    public void deleteDoctorTest() {
        Doctor doctor = Doctor.builder()
                .id(1L)
                .fullName("Dr Mohamed")
                .username("mohamed")
                .email("drmohamed@gmail.com")
                .password("password")
                .age(30)
                .degree("MD")
                .gender("male")
                .phoneNumber("+1320-123-1234")
                .address("MN, St. Cloud")
                .build();

        Appointment appointment = Appointment.builder()
                .appointmentDate("2022-06-20")
                .appointmentTime("09:30")
                .doctor(doctor)
                .build();
        List<Appointment> appointments = new ArrayList<>();
        appointments.add(appointment);

        when(doctorRepository.findById(1L)).thenReturn(Optional.of(doctor));
        when(appointmentRepository.getAllAppointmentsByDoctorId(1L)).thenReturn(appointments);
        assertTrue(doctorService.deleteDoctor(1L));
    }


    /**
     * In this test case we are testing our findDoctorWithUsername method which is searching a doctor with its Username .
     * So, we are expecting a single doctor whose Username  is that we have entered.
     */
    @Test
    public void findDoctorWithUsernameTest() {

        Doctor doctor = Doctor.builder()
                .id(1L)
                .fullName("Dr Mohamed")
                .username("mohamed")
                .email("drmahamed@gmail.com")
                .password("password")
                .age(30)
                .degree("MD")
                .gender("male")
                .phoneNumber("+1320-123-1234")
                .address("MN, St. Cloud")
                .build();
        when(doctorRepository.findByUsername("mohamed")).thenReturn(Optional.of(doctor));
        assertEquals(doctor, doctorService.findDoctorWithUsername("mohamed"));
    }

    /**
     * In this test case we are testing our findDoctorWithEmail method which is searching a doctor with its Email .
     * So, we are expecting a single doctor whose Email is that we have entered.
     */
    @Test
    public void findDoctorWithEmailTest() {

        Doctor doctor = Doctor.builder()
                .id(1L)
                .fullName("Dr Mohamed")
                .username("mohamed")
                .email("drmohamed@gmail.com")
                .password("password")
                .age(30)
                .degree("MD")
                .gender("male")
                .phoneNumber("")
                .address("MN, St. Cloud")
                .build();
        when(doctorRepository.findByEmail("drmohamed@gmail.com")).thenReturn(Optional.of(doctor));
        assertEquals(doctor, doctorService.findDoctorWithEmail("drmohamed@gmail.com"));
    }


    /**
     * In this test case we are testing our getDoctorById method which is searching a doctor with its Id  .
     * So, we are expecting a single doctor whose Id is that we have entered.
     */
    @Test
    public void getDoctorByIdTest() {

        Doctor doctor = Doctor.builder()
                .id(1L)
                .fullName("Dr Mohamed")
                .username("mohamed")
                .email("drmohamed@gmail.com")
                .password("password")
                .age(30)
                .degree("MD")
                .gender("male")
                .phoneNumber("+1320-123-1234")
                .address("MN, St. Cloud")
                .build();
        when(doctorRepository.findById(1L)).thenReturn(Optional.of(doctor));
        assertEquals(doctor, doctorService.getDoctorById(1L));
    }

}
