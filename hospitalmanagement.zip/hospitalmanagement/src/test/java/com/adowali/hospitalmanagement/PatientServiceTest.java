package com.adowali.hospitalmanagement;

import com.adowali.hospitalmanagement.model.Appointment;
import com.adowali.hospitalmanagement.model.Patient;
import com.adowali.hospitalmanagement.repository.AppointmentRepository;
import com.adowali.hospitalmanagement.repository.PatientRepository;
import com.adowali.hospitalmanagement.service.PatientService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@Transactional
public class PatientServiceTest {

    @MockBean
    PatientRepository patientRepository;

    @MockBean
    AppointmentRepository appointmentRepository;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    @Autowired
    PatientService patientService;


    /**
     * In this test case we are testing our get all patients function,
     * which will return us the list of the patients that we have mocked.
     */
    @Test
    public void doctorWithEmailTest() {

        Patient patient = Patient.builder()
                .id(1L)
                .fullName("Ali")
                .username("ali")
                .email("ali@gmail.com")
                .password("password")
                .age(30)
                .gender("male")
                .phoneNumber("+1320-123-1234")
                .address("MN, St. Cloud")
                .build();
        when(patientRepository.findByEmail("ali@gmail.com")).thenReturn(Optional.of(patient));
        assertEquals(patient, patientService.findPatientByEmail("ali@gmail.com").get());
    }

    /**
     * In this test case we are testing our findPatientByUsername method which is searching a Patient with its Username  .
     * So, we are expecting a single Patient whose Username  is that we have entered.
     */
    @Test
    public void findPatientByUsernameTest() {

        Patient patient = Patient.builder()
                .id(1L)
                .fullName("Ali")
                .username("ali")
                .email("ali@gmail.com")
                .password("password")
                .age(30)
                .gender("male")
                .phoneNumber("+1320-123-1234")
                .address("MN, St. Cloud")
                .build();
        when(patientRepository.findByUsername("ali")).thenReturn(Optional.of(patient));
        assertEquals(patient, patientService.findPatientByUsername("ali").get());
    }

    /**
     * In this test case we are testing our save patient function.
     * We are saving a dummy patient and check the return whether it will return us our expected result or not.
     */

    @Test
    public void savePatientTest() {

        Patient patient = Patient.builder()
                .id(1L)
                .fullName("Ali")
                .username("ali")
                .email("ali@gmail.com")
                .password("password")
                .age(30)
                .gender("male")
                .phoneNumber("+1320-123-1234")
                .address("MN, St. Cloud")
                .build();
        when(patientRepository.save(patient)).thenReturn(patient);
        assertEquals(patient, patientService.savePatient(patient));
    }

    /**
     * In this test case we are testing our get all patients function,
     * which will return us the list of the patients that we have mocked.
     */

    @Test
    public void getAllPatientsTest() {

        Patient patient = Patient.builder()
                .id(1L)
                .fullName("Ali")
                .username("ali")
                .email("ali@gmail.com")
                .password("password")
                .age(30)
                .gender("male")
                .phoneNumber("+1320-123-1234")
                .address("MN, St. Cloud")
                .build();

        List<Patient> patientList = new ArrayList<>();
        patientList.add(patient);
        when(patientRepository.findAll()).thenReturn(patientList);
        assertEquals(patientList, patientService.getAllPatients());
    }


    /**
     * In this test case we are testing our getSpecificPatientAppointments method which is searching a Patient with its ID  .
     * So, we are expecting a single Patient whose ID  is that we have entered.
     */
    @Test
    public void getSpecificPatientAppointmentsTest() {

        Patient patient = Patient.builder()
                .id(1L)
                .fullName("Ali")
                .username("ali")
                .email("ali@gmail.com")
                .password("password")
                .age(30)
                .gender("male")
                .phoneNumber("+1320-123-1234")
                .address("MN, St. Cloud")
                .build();

        Appointment appointment = Appointment.builder()
                .appointmentDate("2022-06-20")
                .appointmentTime("09:30")
                .patient(patient)
                .build();
        List<Appointment> appointments = new ArrayList<>();
        appointments.add(appointment);

        when(appointmentRepository.getAllAppointmentsByPatientId(1L)).thenReturn(appointments);
        assertEquals(appointments, patientService.getSpecificPatientAppointments(1L));
    }


}
