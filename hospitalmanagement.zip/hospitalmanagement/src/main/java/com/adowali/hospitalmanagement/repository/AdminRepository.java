package com.adowali.hospitalmanagement.repository;

import com.adowali.hospitalmanagement.model.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AdminRepository extends JpaRepository<Admin, Long> {
    /**
     * In this function we are fetching the admin where username that we will give input
     * @param username
     * @return
     */
    Optional<Admin> findByUsername(String username);
}
