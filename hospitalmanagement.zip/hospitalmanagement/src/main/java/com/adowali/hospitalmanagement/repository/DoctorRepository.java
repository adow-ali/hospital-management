package com.adowali.hospitalmanagement.repository;

import com.adowali.hospitalmanagement.model.Doctor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Long> {
    /**
     * Fetching the doctor by its username
     * @param username
     * @return
     */
    Optional<Doctor> findByUsername(String username);
    /**
     * Fetching the doctor by its email
     * @param email
     * @return
     */
    Optional<Doctor> findByEmail(String email);
}
