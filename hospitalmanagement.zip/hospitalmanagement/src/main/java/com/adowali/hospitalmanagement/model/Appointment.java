package com.adowali.hospitalmanagement.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "appointments")
public class Appointment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank(message = "Kindly select the date")
    private String appointmentDate;
    @NotBlank(message = "Kindly select the time of appointment")
    private String appointmentTime;
    @OneToOne
    Patient patient;
    @OneToOne
    Doctor doctor;
}
