package com.adowali.hospitalmanagement.controller;

import com.adowali.hospitalmanagement.model.Patient;
import com.adowali.hospitalmanagement.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;
import java.util.Optional;

@Controller
public class RegistrationController {

    @Autowired
    PatientService patientService;

    /**
     * This api will show the register page to the patient.
     * @param model
     * @return
     */
    @GetMapping("/register")
    public String register(Model model) {
        model.addAttribute("patient", new Patient());
        return "signup";
    }

    /**
     * This api is accepting the registration details from the registration form and sending to the service.
     * @param patient
     * @param result
     * @param model
     * @return
     */

    @PostMapping("/register")
    public String registerForSubmission(@Valid Patient patient, BindingResult result, Model model) {
        if (!result.hasErrors()) {
            Optional<Patient> userWithSameUsername = patientService.findPatientByUsername(patient.getUsername());
            Optional<Patient> userWithSameEmail = patientService.findPatientByEmail(patient.getEmail());

            if (userWithSameUsername.isPresent()) {
                model.addAttribute("alreadyUsernameExists", true);
            } else if (userWithSameEmail.isPresent()) {
                model.addAttribute("alreadyEmailExists", true);
            } else {
                patientService.savePatient(patient);
                model.addAttribute("successfully", true);
                model.addAttribute("user", new Patient());
            }
        }
        return "signup";
    }
}
