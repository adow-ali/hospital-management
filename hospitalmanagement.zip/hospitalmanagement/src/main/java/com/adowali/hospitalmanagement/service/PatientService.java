package com.adowali.hospitalmanagement.service;

import com.adowali.hospitalmanagement.model.Appointment;
import com.adowali.hospitalmanagement.model.Patient;
import com.adowali.hospitalmanagement.repository.AppointmentRepository;
import com.adowali.hospitalmanagement.repository.PatientRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class PatientService {
    @Autowired
    PatientRepository patientRepository;

    @Autowired
    AppointmentRepository appointmentRepository;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    /**
     * In this function we are finding a patient against its username.
     *
     * @param username
     * @return
     */
    public Optional<Patient> findPatientByUsername(String username) {
        return patientRepository.findByUsername(username);
    }

    /**
     * In this function we are finding a patient with its email.
     *
     * @param email
     * @return
     */
    public Optional<Patient> findPatientByEmail(String email) {
        return patientRepository.findByEmail(email);
    }

    /**
     * In this function we are saving a patient in the database.
     *
     * @param patient
     * @return
     */
    public Patient savePatient(Patient patient) {
        patient.setPassword(bCryptPasswordEncoder.encode(patient.getPassword()));
        return patientRepository.save(patient);
    }

    /**
     * In this function we are fetching all the patients that are present in our database.
     *
     * @return
     */
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    /**
     * In this function we are fetching all the appointments that a specific patient booked.
     *
     * @param patientId
     * @return
     */
    public List<Appointment> getSpecificPatientAppointments(Long patientId) {
        return appointmentRepository.getAllAppointmentsByPatientId(patientId);
    }
}
