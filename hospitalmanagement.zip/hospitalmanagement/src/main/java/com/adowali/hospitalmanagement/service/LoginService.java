package com.adowali.hospitalmanagement.service;

import com.adowali.hospitalmanagement.model.Admin;
import com.adowali.hospitalmanagement.model.Doctor;
import com.adowali.hospitalmanagement.model.Patient;
import com.adowali.hospitalmanagement.repository.AdminRepository;
import com.adowali.hospitalmanagement.repository.DoctorRepository;
import com.adowali.hospitalmanagement.repository.PatientRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Service
@Slf4j
public class LoginService implements UserDetailsService {
    @Autowired
    PatientRepository patientRepository;

    @Autowired
    AdminRepository adminRepository;

    @Autowired
    DoctorRepository doctorRepository;

    /**
     * This method is getting used by Spring Security to find the user from the database by using its username.
     *
     * @param username
     * @return
     * @throws UsernameNotFoundException
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<Patient> patient = patientRepository.findByUsername(username);

        Optional<Admin> admin = adminRepository.findByUsername(username);

        Optional<Doctor> doctor = doctorRepository.findByUsername(username);

        if (patient.isPresent()) {
            log.info("Patient is logged in !!");
            return new org.springframework.security.core.userdetails.User(
                    patient.get().getUsername(),
                    patient.get().getPassword(),
                    getAuthority("ROLE_PATIENT")
            );
        } else if (admin.isPresent()) {
            log.info("Admin is logged in !!");
            return new org.springframework.security.core.userdetails.User(
                    admin.get().getUsername(),
                    admin.get().getPassword(),
                    getAuthority("ROLE_ADMIN")
            );
        } else if (doctor.isPresent()) {
            log.info("Doctor is logged in !!");
            return new org.springframework.security.core.userdetails.User(
                    doctor.get().getUsername(),
                    doctor.get().getPassword(),
                    getAuthority("ROLE_DOCTOR")
            );
        } else {
            throw new UsernameNotFoundException("There is no user against this username");
        }
    }

    /**
     * Fetching the roles of a user
     *
     * @param role
     * @return
     */
    private Set<SimpleGrantedAuthority> getAuthority(String role) {
        Set<SimpleGrantedAuthority> authorities = new HashSet<>();
        authorities.add(new SimpleGrantedAuthority(role));
        return authorities;
    }
}
