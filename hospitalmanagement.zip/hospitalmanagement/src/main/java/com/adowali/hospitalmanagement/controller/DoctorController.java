package com.adowali.hospitalmanagement.controller;

import com.adowali.hospitalmanagement.model.Doctor;
import com.adowali.hospitalmanagement.repository.AppointmentRepository;
import com.adowali.hospitalmanagement.service.DoctorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;

@Slf4j
@Controller
@RequestMapping("/doctors")
public class DoctorController {

    @Autowired
    DoctorService doctorService;

    @Autowired
    AppointmentRepository appointmentRepository;

    /**
     * This api is getting used to show the admin dashboard.
     * @param model
     * @return
     */
    @GetMapping("/dashboard")
    public String dashboard(Model model) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        Doctor doctor = doctorService.findDoctorWithUsername(username);
        model.addAttribute("appointmentsList", appointmentRepository.getAllAppointmentsByDoctorId(doctor.getId()));
        return "doctor-dashboard";
    }

    /**
     * This api is getting used to show all the doctors to the frontend
     * @param model
     * @return
     */
    @GetMapping("/list")
    public String listOfDoctors(Model model) {
        model.addAttribute("doctorsList", doctorService.getAllDoctors());
        return "doctors-list";
    }

    /**
     * This api is getting used to view the page to create a new doctor
     * @param model
     * @return
     */
    @GetMapping("/new")
    public String addNewDoctor(Model model) {
        model.addAttribute("doctor", new Doctor());
        return "add-doctor";
    }

    /**
     * This api is getting used to receive the admin details from the create admin form
     * @param doctor
     * @param bindingResult
     * @param model
     * @return
     */
    @PostMapping("/new")
    public String addNewDoctor(@Valid Doctor doctor, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            return "add-doctor";
        } else if (doctorService.doctorWithEmail(doctor.getEmail())) {
            model.addAttribute("alreadyEmailExists", true);
            return "add-doctor";
        } else if (doctorService.doctorWithUsername(doctor.getUsername())) {
            model.addAttribute("alreadyUsernameExists", true);
            return "add-doctor";
        } else {
            doctorService.saveDoctor(doctor);
            model.addAttribute("successfully", true);
            model.addAttribute("doctor", new Doctor());
            return "add-doctor";
        }
    }

    /**
     * This api is getting used to delete the doctor from the frontend
     * @param doctorId
     * @return
     */
    @GetMapping("/delete/{id}")
    public String deleteDoctor(@PathVariable(name = "id") Long doctorId) {
        doctorService.deleteDoctor(doctorId);
        return "redirect:/doctors/list";
    }

    /**
     * This api is getting used to view the page to update the doctor
     * @param doctorId
     * @param model
     * @return
     */
    @GetMapping("/update/{id}")
    public String updateDoctor(@PathVariable(name = "id") Long doctorId, Model model) {
        model.addAttribute("doctor", doctorService.getDoctorById(doctorId));
        return "update-doctor";
    }

    /**
     * This api is getting used to update the doctor after receiving the details from that update form
     * @param doctor
     * @param bindingResult
     * @param doctorId
     * @param model
     * @return
     */
    @PostMapping("/update/{id}")
    public String updateDoctor(@Valid Doctor doctor, BindingResult bindingResult, @PathVariable(name = "id") Long doctorId, Model model) {
        doctor.setId(doctorId);
        if (bindingResult.hasErrors()) {
            return "update-doctor";
        } else if (doctorService.doctorWithEmail(doctor.getEmail())
                && doctorService.findDoctorWithEmail(doctor.getEmail()).getId().longValue() != doctor.getId()) {
            model.addAttribute("alreadyEmailExists", true);
            return "update-doctor";
        } else if (doctorService.doctorWithUsername(doctor.getUsername())
                && doctorService.findDoctorWithUsername(doctor.getUsername()).getId().longValue() != doctor.getId()) {
            model.addAttribute("alreadyUsernameExists", true);
            return "update-doctor";
        } else {
            doctorService.saveDoctor(doctor);
            model.addAttribute("successfully", true);
            return "update-doctor";
        }
    }

}
