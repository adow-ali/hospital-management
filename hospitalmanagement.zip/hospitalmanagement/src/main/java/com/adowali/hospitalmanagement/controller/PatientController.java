package com.adowali.hospitalmanagement.controller;

import com.adowali.hospitalmanagement.model.Patient;
import com.adowali.hospitalmanagement.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Optional;

@Controller
@RequestMapping("/patients")
public class PatientController {
    @Autowired
    PatientService patientService;

    /**
     * This api is getting used to show the list of patients.
     * @param model
     * @return
     */
    @GetMapping("/list")
    public String listOfPatients(Model model) {
        model.addAttribute("patientsList", patientService.getAllPatients());
        return "patients-list";
    }

    /**
     * This api is getting used to show the dashboard to the patients.
     * @param model
     * @return
     */
    @GetMapping("/dashboard")
    public String patientDashboard(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        Optional<Patient> patient = patientService.findPatientByUsername(username);
        if (patient.isPresent()) {
            model.addAttribute("appointmentsList", patientService.getSpecificPatientAppointments(patient.get().getId()));
            return "patient-dashboard";
        } else {
            return "redirect:/";
        }
    }


}
