package com.adowali.hospitalmanagement.service;

import com.adowali.hospitalmanagement.model.Appointment;
import com.adowali.hospitalmanagement.model.Doctor;
import com.adowali.hospitalmanagement.repository.AppointmentRepository;
import com.adowali.hospitalmanagement.repository.DoctorRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class DoctorService {
    @Autowired
    DoctorRepository doctorRepository;

    @Autowired
    AppointmentRepository appointmentRepository;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    /**
     * In this function, we are saving the doctor in the database
     *
     * @param doctor
     * @return
     */
    public Doctor saveDoctor(Doctor doctor) {
        log.info("Following doctor is getting saved to the database: {}", doctor);

        doctor.setPassword(bCryptPasswordEncoder.encode(doctor.getPassword()));
        return doctorRepository.save(doctor);
    }

    /**
     * In this function, we are fetching all the doctors from the database.
     *
     * @return
     */
    public List<Doctor> getAllDoctors() {
        log.info("Get all doctors method is called !!");
        return doctorRepository.findAll();
    }

    /**
     * In this function, we are finding the doctor with the username
     *
     * @param username
     * @return
     */
    public boolean doctorWithUsername(String username) {
        Optional<Doctor> doctor = doctorRepository.findByUsername(username);
        log.info("Following doctor is fetched from the database: {}", username);
        return doctor.isPresent();
    }

    /**
     * In this function, we are finding whether a doctor with this email is present or not
     *
     * @param email
     * @return
     */
    public boolean doctorWithEmail(String email) {
        Optional<Doctor> doctor = doctorRepository.findByEmail(email);
        log.info("Following doctor is fetched from the database: {}", doctor);
        return doctor.isPresent();
    }

    /**
     * In this function, we are deleting a doctor from the database.
     *
     * @param doctorId
     * @return
     */
    public boolean deleteDoctor(Long doctorId) {
        Optional<Doctor> doctor = doctorRepository.findById(doctorId);
        if (doctor.isPresent()) {
            List<Appointment> appointment = appointmentRepository.getAllAppointmentsByDoctorId(doctorId);
            if (appointment.isEmpty()) {
                log.info("There is no appointment yet made for this doctor");
            } else {
                appointmentRepository.deleteAll(appointment);
            }
            doctorRepository.delete(doctor.get());
            return true;
        } else {
            log.info("There is no doctor against this doctor id: {}", doctorId);
            return false;
        }
    }

    /**
     * In this function, we are finding the doctor with the username
     *
     * @param username
     * @return
     */
    public Doctor findDoctorWithUsername(String username) {
        Optional<Doctor> doctor = doctorRepository.findByUsername(username);
        return doctor.orElse(null);
    }

    /**
     * In this function, we are finding whether a doctor with this email is present or not
     *
     * @param email
     * @return
     */
    public Doctor findDoctorWithEmail(String email) {
        Optional<Doctor> doctor = doctorRepository.findByEmail(email);
        return doctor.orElse(null);
    }

    /**
     * In this function, we are finding whether a doctor with its id
     *
     * @param doctorId
     * @return
     */
    public Doctor getDoctorById(Long doctorId) {
        Optional<Doctor> doctor = doctorRepository.findById(doctorId);
        return doctor.orElse(null);
    }
}
