package com.adowali.hospitalmanagement.repository;

import com.adowali.hospitalmanagement.model.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {

    /**
     * This query is fetching all those appointments where doctor ID is what we are entering.
     * Here we are fetching all appointments of a specific doctor.
     * @param doctorId
     * @return
     */
    @Query(
            value = "SELECT * FROM appointments u WHERE u.doctor_id = ?1",
            nativeQuery = true)
    List<Appointment> getAllAppointmentsByDoctorId(Long doctorId);

    /**
     * This query is fetching all those appointments where patient ID is what we are entering.
     * Here we are fetching all appointments of a specific patients.
     * @param patientId
     * @return
     */
    @Query(
            value = "SELECT * FROM appointments u WHERE u.patient_id = ?1",
            nativeQuery = true)
    List<Appointment> getAllAppointmentsByPatientId(Long patientId);

    /**
     * In this we are doing a query to fetch an appointment where date, time and doctor id is what we entered.
     * Actually this query is show every doctor its own todays appointments.
     * @param appointmentDate
     * @param appointmentTime
     * @param doctorId
     * @return
     */
    Optional<Appointment> findAppointmentByAppointmentDateAndAppointmentTimeAndDoctorId(String appointmentDate, String appointmentTime, Long doctorId);

    /**
     * In this we are finding all appointments which have a specific appointment date and id.
     * @param date
     * @param doctorId
     * @return
     */
    List<Appointment> findAppointmentByAppointmentDateAndDoctorId(String date, Long doctorId);
}
