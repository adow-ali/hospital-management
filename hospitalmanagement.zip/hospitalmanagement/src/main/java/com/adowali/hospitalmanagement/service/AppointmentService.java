package com.adowali.hospitalmanagement.service;

import com.adowali.hospitalmanagement.model.Appointment;
import com.adowali.hospitalmanagement.model.Doctor;
import com.adowali.hospitalmanagement.repository.AppointmentRepository;
import com.adowali.hospitalmanagement.repository.DoctorRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class AppointmentService {
    @Autowired
    AppointmentRepository appointmentRepository;

    @Autowired
    DoctorRepository doctorRepository;

    /**
     * In this function, we are fetching the list of appointments from the database.
     *
     * @return
     */
    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

    /**
     * In this function, we are booking the appointment for a specific doctor.
     *
     * @param appointment
     * @param doctorId
     * @return
     */
    public Long bookAppointment(Appointment appointment, Long doctorId) {
        Optional<Doctor> doctor = doctorRepository.findById(doctorId);
        if (doctor.isPresent()) {
            appointment.setDoctor(doctor.get());
            log.info("Following appointment has been book for a doctor: {}", appointment);

            return appointmentRepository.save(appointment).getId();
        } else {
            throw new RuntimeException("There is no doctor against this doctor ID:" + doctorId);
        }
    }

    /**
     * In this function, we are finding the appointment by the date and time whether that slot is available
     * for that specific doctor or someone already booked that slot.
     *
     * @param date
     * @param time
     * @param doctorId
     * @return
     */
    public boolean findAppointmentByAppointmentDateAndAndAppointmentTimeAndDoctorId(String date, String time, Long doctorId) {
        Optional<Appointment> appointment = appointmentRepository.
                findAppointmentByAppointmentDateAndAppointmentTimeAndDoctorId(date, time, doctorId);
        log.info("Following appointment is fetched: {}", appointment);
        return appointment.isPresent();
    }


    /**
     * In this function, we are fetching all the appointments that a single doctor have today
     *
     * @param todayDate
     * @param doctorId
     * @return
     */
    public List<Appointment> findAppointmentByAppointmentDateAndDoctorId(String todayDate, Long doctorId) {
        return appointmentRepository.findAppointmentByAppointmentDateAndDoctorId(todayDate, doctorId);
    }


    public Optional<Appointment> findAppointmentById(Long appointmentId) {
        return appointmentRepository.findById(appointmentId);
    }

}
