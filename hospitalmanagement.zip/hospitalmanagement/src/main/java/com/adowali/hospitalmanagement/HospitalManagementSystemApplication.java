package com.adowali.hospitalmanagement;

import com.adowali.hospitalmanagement.model.Admin;
import com.adowali.hospitalmanagement.repository.AdminRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Optional;

@SpringBootApplication
public class HospitalManagementSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(HospitalManagementSystemApplication.class, args);
    }

    @Bean
    CommandLineRunner run(AdminRepository adminRepository, BCryptPasswordEncoder passwordEncoder) {
        return args -> {
            Optional<Admin> admin = adminRepository.findByUsername("adow");
            if (!admin.isPresent()) {
                Admin newAdmin = Admin.builder()
                        .fullName("Adow Ali")
                        .email("adow@gmail.com")
                        .username("adow")
                        .password(passwordEncoder.encode("12345"))
                        .build();
                adminRepository.save(newAdmin);
            }

            Optional<Admin> admin1 = adminRepository.findByUsername("admin");
            if (!admin1.isPresent()) {
                Admin newAdmin2 = Admin.builder()
                        .fullName("Admin")
                        .email("admin@gmail.com")
                        .username("admin")
                        .password(passwordEncoder.encode("12345"))
                        .build();
                adminRepository.save(newAdmin2);
            }
        };
    }
}
