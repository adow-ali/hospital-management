package com.adowali.hospitalmanagement.controller;

import com.adowali.hospitalmanagement.service.AdminService;
import com.adowali.hospitalmanagement.service.AppointmentService;
import com.adowali.hospitalmanagement.service.DoctorService;
import com.adowali.hospitalmanagement.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    AdminService adminService;

    @Autowired
    DoctorService doctorService;

    @Autowired
    PatientService patientService;

    @Autowired
    AppointmentService appointmentService;

    /**
     * This controller is getting used to show the Admin Dashboard Page
     * @param model
     * @return
     */
    @GetMapping("/dashboard")
    public String adminDashboard(Model model) {
        model.addAttribute("appointmentsList", appointmentService.getAllAppointments());
        model.addAttribute("doctorsList", doctorService.getAllDoctors());
        model.addAttribute("patientsList", patientService.getAllPatients());
        return "admin-dashboard";
    }

}
