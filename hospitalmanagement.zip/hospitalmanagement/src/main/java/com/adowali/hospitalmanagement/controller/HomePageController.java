package com.adowali.hospitalmanagement.controller;

import com.adowali.hospitalmanagement.model.Admin;
import com.adowali.hospitalmanagement.model.Doctor;
import com.adowali.hospitalmanagement.model.Patient;
import com.adowali.hospitalmanagement.repository.AdminRepository;
import com.adowali.hospitalmanagement.repository.DoctorRepository;
import com.adowali.hospitalmanagement.repository.PatientRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Optional;

@Controller
@Slf4j
public class HomePageController {

    @Autowired
    PatientRepository patientRepository;

    @Autowired
    AdminRepository adminRepository;

    @Autowired
    DoctorRepository doctorRepository;

    /**
     * This is the api that is deciding which dashboard will be rendered on the behalf of that logged in user
     *
     * @return
     */
    @GetMapping("/")
    public String homepage() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        Optional<Patient> patient = patientRepository.findByUsername(username);
        Optional<Admin> admin = adminRepository.findByUsername(username);
        Optional<Doctor> doctor = doctorRepository.findByUsername(username);
        if (patient.isPresent()) {
            log.info("Patient is logged in !!");
            return "redirect:/patients/dashboard";
        } else if (admin.isPresent()) {
            log.info("Admin is logged in !!");
            return "redirect:/admin/dashboard";
        } else if (doctor.isPresent()) {
            log.info("Doctor is logged in !!");
            return "redirect:/doctors/dashboard";
        } else {
            return "index";
        }
    }
}
