package com.adowali.hospitalmanagement.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {
    /**
     * This api is rendering the login page
     * @return
     */
    @GetMapping("/login")
    public String login() {
        return "signin";
    }

    /**
     * This api will be used to show errors on the frontend if happens.
     * @param model
     * @return
     */
    @GetMapping("/login-error")
    public String loginError(Model model) {
        model.addAttribute("error", true);
        return "signin";
    }
}
