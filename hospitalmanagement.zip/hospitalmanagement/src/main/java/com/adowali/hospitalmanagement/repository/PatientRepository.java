package com.adowali.hospitalmanagement.repository;

import com.adowali.hospitalmanagement.model.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PatientRepository extends JpaRepository<Patient, Long> {
    /**
     * Fetching the patient by its username
     * @param username
     * @return
     */
    Optional<Patient> findByUsername(String username);
    /**
     * Fetching the patient by its email
     * @param email
     * @return
     */
    Optional<Patient> findByEmail(String email);
}
