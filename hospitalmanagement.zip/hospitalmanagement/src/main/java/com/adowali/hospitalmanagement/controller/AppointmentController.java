package com.adowali.hospitalmanagement.controller;

import com.adowali.hospitalmanagement.model.Appointment;
import com.adowali.hospitalmanagement.model.Doctor;
import com.adowali.hospitalmanagement.model.Patient;
import com.adowali.hospitalmanagement.repository.AppointmentRepository;
import com.adowali.hospitalmanagement.service.AppointmentService;
import com.adowali.hospitalmanagement.service.DoctorService;
import com.adowali.hospitalmanagement.service.PatientService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Optional;

@Controller
@Slf4j
@RequestMapping("/appointment")
public class AppointmentController {

    @Autowired
    AppointmentService appointmentService;

    @Autowired
    AppointmentRepository appointmentRepository;

    @Autowired
    PatientService patientService;

    @Autowired
    DoctorService doctorService;

    /**
     * This controller is getting used to show all the appointments on the frontend
     *
     * @param model
     * @return
     */
    @GetMapping("/allAppointments")
    public String listOfAppointments(Model model) {
        model.addAttribute("appointmentsList", appointmentService.getAllAppointments());
        return "appointments-list";
    }

    /**
     * This api is getting used to view the page to book an appointment
     *
     * @param doctorId
     * @param model
     * @return
     */
    @GetMapping("/book/{id}")
    public String bookAppointment(@PathVariable(name = "id") Long doctorId, Model model) {
        model.addAttribute("appointment", new Appointment());
        model.addAttribute("doctorId", doctorId);
        return "book-appointment";
    }

    /**
     * This api is getting used to book an appointment from the frontend
     *
     * @param appointment
     * @param doctorId
     * @param model
     * @return
     * @throws ParseException
     */
    @PostMapping("/book/{id}")
    public String bookAppointment(Appointment appointment, @PathVariable(name = "id") Long doctorId, Model model) throws ParseException {
        model.addAttribute("doctorId", doctorId);
        appointment.setId(null);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        //convert String to LocalDate
        LocalDate localDate = LocalDate.parse(appointment.getAppointmentDate(), formatter);

        if (localDate.isBefore(LocalDate.now())) {
            model.addAttribute("oldDate", true);
            return "book-appointment";
        }

        final SimpleDateFormat sdf = new SimpleDateFormat("H:mm");
        final Date dateObj = sdf.parse(appointment.getAppointmentTime());

        appointment.setAppointmentTime(new SimpleDateFormat("K:mm a").format(dateObj));

        if (appointmentService.findAppointmentByAppointmentDateAndAndAppointmentTimeAndDoctorId(appointment.getAppointmentDate(), appointment.getAppointmentTime(), doctorId)) {
            model.addAttribute("slotNotAvailable", true);
            return "book-appointment";
        }
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        Optional<Patient> patient = patientService.findPatientByUsername(username);
        if (patient.isPresent()) {
            appointment.setPatient(patient.get());
            Long appointmentId = appointmentService.bookAppointment(appointment, doctorId);
            model.addAttribute("appointmentId", appointmentId);
            model.addAttribute("successfully", true);
        }
        return "book-appointment";
    }

    /**
     * This api is delete the patient appointment
     * @param appointmentId
     * @return
     */
    @GetMapping("/delete/{id}")
    public String deleteAppointment(@PathVariable(name = "id") Long appointmentId) {
        Optional<Appointment> appointment = appointmentService.findAppointmentById(appointmentId);
        appointment.ifPresent(value -> appointmentRepository.delete(value));
        return "redirect:/patients/dashboard";
    }

    /**
     * This api is updating the patient appointment
     * @param appointmentId
     * @param model
     * @return
     */
    @GetMapping("/update/{id}")
    public String updateAppointment(@PathVariable(name = "id") Long appointmentId, Model model) {
        Optional<Appointment> appointment = appointmentService.findAppointmentById(appointmentId);
        if (appointment.isPresent()) {
            model.addAttribute("appointment", appointment.get());

            model.addAttribute("doctorId", appointment.get().getDoctor().getId());
        }
        return "update-appointment";
    }

    /**
     * This api is updating the patient appointment by accepting the form parameters
     * @param appointment
     * @param doctorId
     * @param model
     * @return
     * @throws ParseException
     */
    @PostMapping("/update/{id}")
    public String updatedAppointment(Appointment appointment, @PathVariable(name = "id") Long doctorId, Model model) throws ParseException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        //convert String to LocalDate
        LocalDate localDate = LocalDate.parse(appointment.getAppointmentDate(), formatter);

        if (localDate.isBefore(LocalDate.now())) {
            model.addAttribute("oldDate", true);
            return "update-appointment";
        }

        final SimpleDateFormat sdf = new SimpleDateFormat("H:mm");
        final Date dateObj = sdf.parse(appointment.getAppointmentTime());

        appointment.setAppointmentTime(new SimpleDateFormat("K:mm a").format(dateObj));

        appointment.setDoctor(doctorService.getDoctorById(doctorId));

        if (appointmentService.findAppointmentByAppointmentDateAndAndAppointmentTimeAndDoctorId(appointment.getAppointmentDate(), appointment.getAppointmentTime(), doctorId)) {
            model.addAttribute("slotNotAvailable", true);
            return "update-appointment";
        }
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        Optional<Patient> patient = patientService.findPatientByUsername(username);
        if (patient.isPresent()) {
            appointment.setPatient(patient.get());
            appointmentRepository.save(appointment);
            model.addAttribute("successfully", true);
        }
        return "update-appointment";
    }

    /**
     * This api is getting used to show all the today's appointments to a doctor
     *
     * @param model
     * @return
     */
    @GetMapping("/today")
    public String todayAppointments(Model model) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String todayDate = formatter.format(new Date());

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        Doctor doctor = doctorService.findDoctorWithUsername(username);

        model.addAttribute("appointmentsList", appointmentService.findAppointmentByAppointmentDateAndDoctorId(todayDate, doctor.getId()));
        return "doctor-dashboard";

    }
}
