package com.adowali.hospitalmanagement.service;

import com.adowali.hospitalmanagement.model.Admin;
import com.adowali.hospitalmanagement.repository.AdminRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AdminService {
    @Autowired
    AdminRepository adminRepository;

    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

    /**
     * In this function, we are storing the admin object in the database.
     *
     * @param admin
     * @return
     */
    public Admin saveAdmin(Admin admin) {
        admin.setPassword(bCryptPasswordEncoder.encode(admin.getPassword()));
        log.info("Admin is getting saved into the database: {}", admin);
        return adminRepository.save(admin);
    }
}
